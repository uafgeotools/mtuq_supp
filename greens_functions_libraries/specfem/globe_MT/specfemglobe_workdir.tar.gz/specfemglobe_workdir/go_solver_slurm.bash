#!/bin/bash

#SBATCH -p t2standard
#SBATCH --ntasks=960
#SBATCH -t 2:00:00
#SBATCH --output=OUTPUT_FILES/%j.o
#SBATCH --job-name=go_solver

ulimit -s unlimited
ulimit -l unlimited

umask 022

cd $SLURM_SUBMIT_DIR

# script to run the solver
# read Par_file to get information about the run
# compute total number of nodes needed
#NPROC=`grep ^NPROC DATA/Par_file | grep -v -E '^[[:space:]]*#' | cut -d = -f 2`
NPROC_XI=`grep ^NPROC_XI DATA/Par_file | cut -d = -f 2 `
NPROC_ETA=`grep ^NPROC_ETA DATA/Par_file | cut -d = -f 2`
NCHUNKS=`grep ^NCHUNKS DATA/Par_file | cut -d = -f 2 `

NSIM=`grep ^NUMBER_OF_SIMULTANEOUS_RUNS DATA/Par_file | cut -d = -f 2`
# total number of nodes is the product of the values read
NPROC=$(( $NSIM * $NCHUNKS * $NPROC_XI * $NPROC_ETA ))


mkdir -p OUTPUT_FILES

# backup files used for this simulation
cp go_solver_slurm.bash OUTPUT_FILES/
cp DATA/Par_file OUTPUT_FILES/
cp DATA/STATIONS OUTPUT_FILES/
cp DATA/CMTSOLUTION OUTPUT_FILES/
cp src/shared/constants.h OUTPUT_FILES/

# save a complete copy of source files
#rm -rf OUTPUT_FILES/src
#cp -rp ./src OUTPUT_FILES/

# obtain job information
cat $SLURM_JOB_NODELIST > OUTPUT_FILES/compute_nodes
echo "$SLURM_JOBID" > OUTPUT_FILES/jobid

echo starting solver on $NPROC processors
echo " "

sleep 2
mpiexec -n $NPROC ./bin/xspecfem3D

cp DATA/STATIONS_FILTERED OUTPUT_FILES/

echo "finished successfully"
