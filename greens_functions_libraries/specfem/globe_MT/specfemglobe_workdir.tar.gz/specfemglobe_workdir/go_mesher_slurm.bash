#!/bin/bash

#SBATCH -p t2standard
#SBATCH --ntasks=160
#SBATCH -t 30
#SBATCH --output=OUTPUT_FILES/%j.o
#SBATCH --job-name=go_mesher

ulimit -s unlimited
ulimit -l unlimited

umask 022

cd $SLURM_SUBMIT_DIR

# script to run the mesher
# read Par_file to get information about the run
# compute total number of nodes needed
#NPROC=`grep ^NPROC DATA/Par_file | grep -v -E '^[[:space:]]*#' | cut -d = -f 2`
NPROC_XI=`grep ^NPROC_XI DATA/Par_file | cut -d = -f 2 `
NPROC_ETA=`grep ^NPROC_ETA DATA/Par_file | cut -d = -f 2`
NCHUNKS=`grep ^NCHUNKS DATA/Par_file | cut -d = -f 2 `

# total number of nodes is the product of the values read
NPROC=$(( $NCHUNKS * $NPROC_XI * $NPROC_ETA ))

mkdir -p OUTPUT_FILES

LOCALPATH=`grep ^LOCAL_PATH DATA/Par_file | grep -v -E '^[[:space:]]*#' | cut -d = -f 2`
mkdir -p $LOCALPATH

# backup mesh files used for this simulation
cp go_mesher_slurm.bash OUTPUT_FILES/
cp -r DATA/meshfem3D_files OUTPUT_FILES/

# obtain job information
cat $SLURM_JOB_NODELIST > OUTPUT_FILES/compute_nodes
echo "$SLURM_JOBID" > OUTPUT_FILES/jobid

echo starting mesher on $NPROC processors
echo " "

sleep 2
mpiexec -n $NPROC ./bin/xmeshfem3D

cp DATA/STATIONS_FILTERED OUTPUT_FILES/

echo "done"
